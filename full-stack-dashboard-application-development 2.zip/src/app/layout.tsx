import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ToastProvider } from "@/components/ui/toast";

export const metadata: Metadata = {
  title: "Жора Крутой представляет Фигню — Просто фигня",
  description:
    "Мы не знаем, что это. Вы не знаете, зачем это. Но как только вы это попробуете — жизнь никогда не будет прежней. Самое необъяснимое открытие десятилетия.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="bg-slate-50 text-slate-900 antialiased">
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
